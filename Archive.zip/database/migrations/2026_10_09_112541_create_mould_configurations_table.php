<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mould_configurations', function (Blueprint $table) {
            $table->uuid('id')->primary();

            $table->string('code', 50)->unique();
            $table->string('name', 150);
            $table->string('mould_type', 40);
            $table->unsignedSmallInteger('nominal_layer_count')->default(2);
            $table->text('description')->nullable();
            $table->boolean('is_active')->default(true);
            $table->text('notes')->nullable();

            $table->timestamps();
            $table->softDeletes();

            $table->index('mould_type');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mould_configurations');
    }
};